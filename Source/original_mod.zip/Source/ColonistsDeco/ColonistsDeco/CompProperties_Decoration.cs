﻿using Verse;

namespace ColonistsDeco
{
    public class CompProperties_Decoration : CompProperties
    {
        public string decorationName;

        public CompProperties_Decoration()
        {
            compClass = typeof(CompDecoration);
        }
    }
}
