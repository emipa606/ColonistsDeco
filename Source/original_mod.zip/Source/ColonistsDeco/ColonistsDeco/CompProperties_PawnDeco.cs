﻿using Verse;

namespace ColonistsDeco
{
    class CompProperties_PawnDeco : CompProperties
    {
        public CompProperties_PawnDeco()
        {
            compClass = typeof(CompPawnDeco);
        }
    }
}
