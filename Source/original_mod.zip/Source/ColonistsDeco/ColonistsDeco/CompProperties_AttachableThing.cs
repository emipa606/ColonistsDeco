﻿using Verse;

namespace ColonistsDeco
{
    class CompProperties_AttachableThing : CompProperties
    {
        public CompProperties_AttachableThing()
        {
            compClass = typeof(CompAttachableThing);
        }
    }
}
